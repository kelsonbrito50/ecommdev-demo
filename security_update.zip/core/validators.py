"""
File upload validators for security.
Prevents malicious file uploads by validating file types, sizes, and content.
"""
import magic
from django.core.exceptions import ValidationError
from django.core.validators import FileExtensionValidator
from django.utils.translation import gettext_lazy as _


# Maximum file sizes (in bytes)
MAX_IMAGE_SIZE = 5 * 1024 * 1024  # 5 MB
MAX_DOCUMENT_SIZE = 10 * 1024 * 1024  # 10 MB
MAX_AVATAR_SIZE = 2 * 1024 * 1024  # 2 MB

# Allowed MIME types
ALLOWED_IMAGE_MIME_TYPES = [
    'image/jpeg',
    'image/png',
    'image/gif',
    'image/webp',
    'image/svg+xml',
]

ALLOWED_DOCUMENT_MIME_TYPES = [
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'text/plain',
    'text/csv',
]

# File extension validators
image_extension_validator = FileExtensionValidator(
    allowed_extensions=['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'],
    message=_('Tipo de arquivo não permitido. Use: JPG, PNG, GIF, WebP ou SVG.')
)

document_extension_validator = FileExtensionValidator(
    allowed_extensions=['pdf', 'doc', 'docx', 'xls', 'xlsx', 'txt', 'csv'],
    message=_('Tipo de arquivo não permitido. Use: PDF, DOC, DOCX, XLS, XLSX, TXT ou CSV.')
)


def validate_file_size(file, max_size):
    """Validate that file size does not exceed maximum."""
    if file.size > max_size:
        max_mb = max_size / (1024 * 1024)
        raise ValidationError(
            _('Arquivo muito grande. Tamanho máximo: %(max_size).1f MB.'),
            params={'max_size': max_mb},
            code='file_too_large'
        )


def validate_mime_type(file, allowed_types):
    """
    Validate file MIME type by reading file content (not just extension).
    This prevents attacks where malicious files are renamed with safe extensions.
    """
    # Read the first 2048 bytes to detect MIME type
    file.seek(0)
    file_header = file.read(2048)
    file.seek(0)  # Reset file pointer

    try:
        mime = magic.from_buffer(file_header, mime=True)
    except Exception:
        # If magic fails, reject the file for safety
        raise ValidationError(
            _('Não foi possível verificar o tipo do arquivo.'),
            code='mime_detection_failed'
        )

    if mime not in allowed_types:
        raise ValidationError(
            _('Tipo de arquivo não permitido: %(mime_type)s'),
            params={'mime_type': mime},
            code='invalid_mime_type'
        )


class ImageValidator:
    """
    Validator for image uploads.
    Checks file extension, size, and actual MIME type.
    """

    def __init__(self, max_size=MAX_IMAGE_SIZE):
        self.max_size = max_size

    def __call__(self, file):
        # Validate extension
        image_extension_validator(file)

        # Validate file size
        validate_file_size(file, self.max_size)

        # Validate actual MIME type (content-based, not extension-based)
        validate_mime_type(file, ALLOWED_IMAGE_MIME_TYPES)

    def deconstruct(self):
        return (
            'core.validators.ImageValidator',
            [],
            {'max_size': self.max_size}
        )


class DocumentValidator:
    """
    Validator for document uploads.
    Checks file extension, size, and actual MIME type.
    """

    def __init__(self, max_size=MAX_DOCUMENT_SIZE):
        self.max_size = max_size

    def __call__(self, file):
        # Validate extension
        document_extension_validator(file)

        # Validate file size
        validate_file_size(file, self.max_size)

        # Validate actual MIME type
        validate_mime_type(file, ALLOWED_DOCUMENT_MIME_TYPES)

    def deconstruct(self):
        return (
            'core.validators.DocumentValidator',
            [],
            {'max_size': self.max_size}
        )


class AvatarValidator:
    """
    Stricter validator for user avatar/profile photos.
    Smaller size limit and only common image formats.
    """

    def __init__(self, max_size=MAX_AVATAR_SIZE):
        self.max_size = max_size
        self.allowed_types = ['image/jpeg', 'image/png', 'image/webp']

    def __call__(self, file):
        # Validate extension (stricter for avatars)
        ext_validator = FileExtensionValidator(
            allowed_extensions=['jpg', 'jpeg', 'png', 'webp'],
            message=_('Use JPG, PNG ou WebP para foto de perfil.')
        )
        ext_validator(file)

        # Validate file size
        validate_file_size(file, self.max_size)

        # Validate actual MIME type
        validate_mime_type(file, self.allowed_types)

    def deconstruct(self):
        return (
            'core.validators.AvatarValidator',
            [],
            {'max_size': self.max_size}
        )


# Pre-configured validator instances for common use cases
validate_image = ImageValidator()
validate_avatar = AvatarValidator()
validate_document = DocumentValidator()
