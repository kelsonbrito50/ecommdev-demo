"""
Template filters for HTML sanitization to prevent XSS attacks.
"""
import bleach
from django import template
from django.utils.safestring import mark_safe

register = template.Library()

# Allowed HTML tags for content fields
ALLOWED_TAGS = [
    'a', 'abbr', 'acronym', 'address', 'b', 'blockquote', 'br', 'code',
    'div', 'em', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'hr', 'i', 'img',
    'li', 'ol', 'p', 'pre', 'span', 'strong', 'table', 'tbody', 'td',
    'tfoot', 'th', 'thead', 'tr', 'ul', 'figure', 'figcaption', 'video',
    'source', 'iframe', 'section', 'article', 'aside', 'header', 'footer',
    'nav', 'main', 'mark', 'small', 'sub', 'sup', 'del', 'ins', 'cite',
]

# Allowed attributes for each tag
ALLOWED_ATTRIBUTES = {
    '*': ['class', 'id', 'style'],
    'a': ['href', 'title', 'target', 'rel'],
    'abbr': ['title'],
    'acronym': ['title'],
    'img': ['src', 'alt', 'title', 'width', 'height', 'loading'],
    'iframe': ['src', 'width', 'height', 'frameborder', 'allowfullscreen'],
    'video': ['src', 'width', 'height', 'controls', 'autoplay', 'muted', 'loop'],
    'source': ['src', 'type'],
    'table': ['border', 'cellpadding', 'cellspacing'],
    'td': ['colspan', 'rowspan'],
    'th': ['colspan', 'rowspan', 'scope'],
}

# Allowed URL schemes
ALLOWED_PROTOCOLS = ['http', 'https', 'mailto', 'tel']


def clean_html(value):
    """
    Sanitize HTML content using bleach.
    Removes potentially dangerous tags and attributes while preserving safe content.
    """
    if not value:
        return ''

    cleaned = bleach.clean(
        value,
        tags=ALLOWED_TAGS,
        attributes=ALLOWED_ATTRIBUTES,
        protocols=ALLOWED_PROTOCOLS,
        strip=True,
    )
    return cleaned


@register.filter(name='sanitize')
def sanitize_html(value):
    """
    Template filter to sanitize HTML content and mark it safe for rendering.

    Usage in templates:
        {{ content|sanitize }}

    This replaces the unsafe pattern of {{ content|safe }} by first sanitizing
    the HTML to remove potentially malicious scripts and attributes.
    """
    return mark_safe(clean_html(value))


@register.filter(name='sanitize_strict')
def sanitize_html_strict(value):
    """
    Stricter sanitization that only allows basic formatting tags.
    Use this for user-generated content where less HTML is needed.

    Usage in templates:
        {{ user_content|sanitize_strict }}
    """
    if not value:
        return ''

    strict_tags = ['b', 'i', 'u', 'em', 'strong', 'p', 'br', 'ul', 'ol', 'li']
    strict_attrs = {'*': ['class']}

    cleaned = bleach.clean(
        value,
        tags=strict_tags,
        attributes=strict_attrs,
        strip=True,
    )
    return mark_safe(cleaned)
