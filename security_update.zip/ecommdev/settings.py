"""
Django settings for ECOMMDEV - Web Development Agency Platform
www.ecommdev.com.br - Bilingual (PT-BR / EN)
"""

import sys
import warnings
from datetime import timedelta
from pathlib import Path

from decouple import config, Csv, UndefinedValueError

# Build paths inside the project like this: BASE_DIR / 'subdir'.
BASE_DIR = Path(__file__).resolve().parent.parent

# =============================================================================
# SECURITY SETTINGS
# =============================================================================

# DEBUG defaults to False for security - must explicitly set to True for development
DEBUG = config('DEBUG', default=False, cast=bool)

# SECRET_KEY handling: required in production, generates warning in development
try:
    SECRET_KEY = config('SECRET_KEY')
except UndefinedValueError:
    if DEBUG:
        # Only allow insecure key in DEBUG mode with warning
        SECRET_KEY = 'django-insecure-dev-key-DO-NOT-USE-IN-PRODUCTION'
        warnings.warn(
            "SECRET_KEY not set! Using insecure development key. "
            "Set SECRET_KEY environment variable before deploying to production.",
            RuntimeWarning
        )
    else:
        raise RuntimeError(
            "SECRET_KEY environment variable is required in production. "
            "Generate one with: python -c \"from django.core.management.utils import get_random_secret_key; print(get_random_secret_key())\""
        )

ALLOWED_HOSTS = config('ALLOWED_HOSTS', default='localhost,127.0.0.1', cast=Csv())

# Production security check
if not DEBUG and ALLOWED_HOSTS == ['localhost', '127.0.0.1']:
    warnings.warn(
        "ALLOWED_HOSTS is set to localhost only but DEBUG=False. "
        "Configure ALLOWED_HOSTS for your production domain.",
        RuntimeWarning
    )

# =============================================================================
# APPLICATION DEFINITION
# =============================================================================

INSTALLED_APPS = [
    # Django Core
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',

    # Third Party Apps
    'rest_framework',
    'rest_framework_simplejwt',
    'corsheaders',
    'csp',
    'axes',

    # Local Apps
    'core.apps.CoreConfig',
    'servicos.apps.ServicosConfig',
    'pacotes.apps.PacotesConfig',
    'orcamentos.apps.OrcamentosConfig',
    'portfolio.apps.PortfolioConfig',
    'blog.apps.BlogConfig',
    'clientes.apps.ClientesConfig',
    'projetos.apps.ProjetosConfig',
    'suporte.apps.SuporteConfig',
    'faturas.apps.FaturasConfig',
    'notificacoes.apps.NotificacoesConfig',
    'api.apps.ApiConfig',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'csp.middleware.CSPMiddleware',
    'corsheaders.middleware.CorsMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.locale.LocaleMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
    'axes.middleware.AxesMiddleware',
]

ROOT_URLCONF = 'ecommdev.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR / 'templates'],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
                'django.template.context_processors.i18n',
                'core.context_processors.site_settings',
            ],
        },
    },
]

WSGI_APPLICATION = 'ecommdev.wsgi.application'

# =============================================================================
# DATABASE
# =============================================================================

DB_ENGINE = config('DB_ENGINE', default='django.db.backends.sqlite3')

if 'postgresql' in DB_ENGINE:
    DATABASES = {
        'default': {
            'ENGINE': DB_ENGINE,
            'NAME': config('DB_NAME', default='ecommdev_db'),
            'USER': config('DB_USER', default='ecommdev_user'),
            'PASSWORD': config('DB_PASSWORD', default=''),
            'HOST': config('DB_HOST', default='localhost'),
            'PORT': config('DB_PORT', default='5432'),
        }
    }
else:
    DATABASES = {
        'default': {
            'ENGINE': 'django.db.backends.sqlite3',
            'NAME': BASE_DIR / config('DB_NAME', default='db.sqlite3'),
        }
    }

# =============================================================================
# CACHE CONFIGURATION
# =============================================================================

# Use Redis in production, local memory in development
REDIS_URL = config('REDIS_URL', default='')

if REDIS_URL:
    CACHES = {
        'default': {
            'BACKEND': 'django_redis.cache.RedisCache',
            'LOCATION': REDIS_URL,
            'OPTIONS': {
                'CLIENT_CLASS': 'django_redis.client.DefaultClient',
            }
        }
    }
else:
    CACHES = {
        'default': {
            'BACKEND': 'django.core.cache.backends.locmem.LocMemCache',
            'LOCATION': 'unique-snowflake',
        }
    }

# =============================================================================
# PASSWORD VALIDATION
# =============================================================================

AUTH_PASSWORD_VALIDATORS = [
    {'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator'},
    {'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator', 'OPTIONS': {'min_length': 8}},
    {'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator'},
    {'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator'},
]

# =============================================================================
# INTERNATIONALIZATION (i18n)
# =============================================================================

LANGUAGE_CODE = config('LANGUAGE_CODE', default='pt-br')
TIME_ZONE = config('TIME_ZONE', default='America/Fortaleza')
USE_I18N = True
USE_L10N = True
USE_TZ = True

# Available languages
LANGUAGES = [
    ('pt-br', 'Português (Brasil)'),
    ('en', 'English'),
]

# Locale paths
LOCALE_PATHS = [
    BASE_DIR / 'locale',
]

# =============================================================================
# STATIC & MEDIA FILES
# =============================================================================

STATIC_URL = '/static/'
STATICFILES_DIRS = [BASE_DIR / 'static']
STATIC_ROOT = BASE_DIR / 'staticfiles'

MEDIA_URL = '/media/'
MEDIA_ROOT = BASE_DIR / 'media'

# =============================================================================
# DEFAULT PRIMARY KEY
# =============================================================================

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

# =============================================================================
# CUSTOM USER MODEL
# =============================================================================

AUTH_USER_MODEL = 'clientes.Usuario'

# =============================================================================
# AUTHENTICATION
# =============================================================================

LOGIN_URL = '/login/'
LOGIN_REDIRECT_URL = '/dashboard/'
LOGOUT_REDIRECT_URL = '/'

AUTHENTICATION_BACKENDS = [
    'axes.backends.AxesStandaloneBackend',
    'django.contrib.auth.backends.ModelBackend',
]

# =============================================================================
# REST FRAMEWORK
# =============================================================================

REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': [
        'rest_framework_simplejwt.authentication.JWTAuthentication',
        'rest_framework.authentication.SessionAuthentication',
    ],
    'DEFAULT_PERMISSION_CLASSES': [
        'rest_framework.permissions.IsAuthenticatedOrReadOnly',
    ],
    'DEFAULT_PAGINATION_CLASS': 'rest_framework.pagination.PageNumberPagination',
    'PAGE_SIZE': 10,
    'DEFAULT_THROTTLE_CLASSES': [
        'rest_framework.throttling.AnonRateThrottle',
        'rest_framework.throttling.UserRateThrottle',
    ],
    'DEFAULT_THROTTLE_RATES': {
        'anon': '100/hour',
        'user': '1000/hour',
    },
}

# =============================================================================
# JWT SETTINGS
# =============================================================================

SIMPLE_JWT = {
    'ACCESS_TOKEN_LIFETIME': timedelta(minutes=config('JWT_ACCESS_TOKEN_LIFETIME', default=60, cast=int)),
    'REFRESH_TOKEN_LIFETIME': timedelta(minutes=config('JWT_REFRESH_TOKEN_LIFETIME', default=10080, cast=int)),
    'ROTATE_REFRESH_TOKENS': True,
    'BLACKLIST_AFTER_ROTATION': True,
    'AUTH_HEADER_TYPES': ('Bearer',),
    'AUTH_TOKEN_CLASSES': ('rest_framework_simplejwt.tokens.AccessToken',),
}

# =============================================================================
# CORS SETTINGS
# =============================================================================

# Production CORS origins (always allowed)
_PRODUCTION_CORS_ORIGINS = [
    'https://www.ecommdev.com.br',
    'https://ecommdev.com.br',
]

# Development CORS origins (only in DEBUG mode)
_DEVELOPMENT_CORS_ORIGINS = [
    'http://localhost:3000',
    'http://localhost:8000',
    'http://127.0.0.1:8000',
]

# Only allow localhost origins in development
if DEBUG:
    CORS_ALLOWED_ORIGINS = _PRODUCTION_CORS_ORIGINS + _DEVELOPMENT_CORS_ORIGINS
else:
    CORS_ALLOWED_ORIGINS = _PRODUCTION_CORS_ORIGINS

CORS_ALLOW_CREDENTIALS = True

# Additional CORS settings for security
CORS_ALLOW_METHODS = [
    'DELETE',
    'GET',
    'OPTIONS',
    'PATCH',
    'POST',
    'PUT',
]

CORS_ALLOW_HEADERS = [
    'accept',
    'accept-encoding',
    'authorization',
    'content-type',
    'dnt',
    'origin',
    'user-agent',
    'x-csrftoken',
    'x-requested-with',
]

# CSRF Trusted Origins (required for Django 4.x)
CSRF_TRUSTED_ORIGINS = [
    'https://www.ecommdev.com.br',
    'https://ecommdev.com.br',
    'https://mrdev02.pythonanywhere.com',
]

# =============================================================================
# EMAIL SETTINGS
# =============================================================================

EMAIL_BACKEND = config('EMAIL_BACKEND', default='django.core.mail.backends.console.EmailBackend')
EMAIL_HOST = config('EMAIL_HOST', default='smtp.gmail.com')
EMAIL_PORT = config('EMAIL_PORT', default=587, cast=int)
EMAIL_USE_TLS = config('EMAIL_USE_TLS', default=True, cast=bool)
EMAIL_HOST_USER = config('EMAIL_HOST_USER', default='')
EMAIL_HOST_PASSWORD = config('EMAIL_HOST_PASSWORD', default='')
DEFAULT_FROM_EMAIL = config('DEFAULT_FROM_EMAIL', default='ECOMMDEV <contato@ecommdev.com.br>')

# =============================================================================
# CONTENT SECURITY POLICY (CSP) - django-csp 4.0+ format
# =============================================================================

# CSP helps prevent XSS attacks by controlling which resources can be loaded

# CSP Directives configuration
_CSP_DIRECTIVES = {
    'default-src': ("'self'",),
    'script-src': (
        "'self'",
        "'unsafe-inline'",  # Required for some Django admin functionality
        "https://www.googletagmanager.com",
        "https://www.google-analytics.com",
        "https://cdn.jsdelivr.net",
        "https://cdnjs.cloudflare.com",
    ),
    'style-src': (
        "'self'",
        "'unsafe-inline'",  # Required for inline styles
        "https://fonts.googleapis.com",
        "https://cdn.jsdelivr.net",
        "https://cdnjs.cloudflare.com",
    ),
    'font-src': (
        "'self'",
        "https://fonts.gstatic.com",
        "https://cdn.jsdelivr.net",
        "https://cdnjs.cloudflare.com",
    ),
    'img-src': (
        "'self'",
        "data:",
        "https:",  # Allow images from HTTPS sources
    ),
    'connect-src': (
        "'self'",
        "https://www.google-analytics.com",
        "https://api.mercadopago.com",
    ),
    'frame-src': (
        "'self'",
        "https://www.youtube.com",
        "https://www.youtube-nocookie.com",
        "https://player.vimeo.com",
    ),
    'media-src': ("'self'",),
    'object-src': ("'none'",),
    'base-uri': ("'self'",),
    'form-action': ("'self'",),
}

# In development, use report-only mode; in production, enforce CSP
if DEBUG:
    CONTENT_SECURITY_POLICY_REPORT_ONLY = {
        'DIRECTIVES': _CSP_DIRECTIVES,
    }
    CONTENT_SECURITY_POLICY = None
else:
    CONTENT_SECURITY_POLICY = {
        'DIRECTIVES': _CSP_DIRECTIVES,
    }
    CONTENT_SECURITY_POLICY_REPORT_ONLY = None

# =============================================================================
# DJANGO-AXES (Login Attempt Throttling)
# =============================================================================

# Protect against brute force attacks
AXES_FAILURE_LIMIT = 5  # Number of failed attempts before lockout
AXES_COOLOFF_TIME = 1  # Lockout duration in hours
AXES_RESET_ON_SUCCESS = True  # Reset failed attempts on successful login
AXES_LOCKOUT_CALLABLE = None  # Use default lockout response

# What to track - lock by username and IP combination
AXES_LOCKOUT_PARAMETERS = [['username', 'ip_address']]

# Form field for username
AXES_USERNAME_FORM_FIELD = 'username'

# Logging
AXES_VERBOSE = True  # Log authentication attempts

# Cache backend for axes (uses default cache)
AXES_CACHE = 'default'

# IP address handling - use ipware for proper IP detection
AXES_IPWARE_PROXY_COUNT = config('AXES_PROXY_COUNT', default=0, cast=int)
AXES_IPWARE_META_PRECEDENCE_ORDER = (
    'HTTP_X_FORWARDED_FOR',
    'REMOTE_ADDR',
)

# =============================================================================
# SECURITY SETTINGS (Production)
# =============================================================================

if not DEBUG:
    SECURE_SSL_REDIRECT = True
    SESSION_COOKIE_SECURE = True
    CSRF_COOKIE_SECURE = True
    SECURE_HSTS_SECONDS = 31536000
    SECURE_HSTS_INCLUDE_SUBDOMAINS = True
    SECURE_HSTS_PRELOAD = True
    SECURE_BROWSER_XSS_FILTER = True
    SECURE_CONTENT_TYPE_NOSNIFF = True
    X_FRAME_OPTIONS = 'DENY'

# =============================================================================
# SITE SETTINGS
# =============================================================================

SITE_URL = config('SITE_URL', default='http://localhost:8000')
SITE_NAME = 'ECOMMDEV'
SITE_DESCRIPTION = 'Desenvolvimento Web Profissional para Pequenas e Médias Empresas'

# =============================================================================
# PAYMENT SETTINGS (Mercado Pago)
# =============================================================================

MERCADOPAGO_ACCESS_TOKEN = config('MERCADOPAGO_ACCESS_TOKEN', default='')
MERCADOPAGO_PUBLIC_KEY = config('MERCADOPAGO_PUBLIC_KEY', default='')
MERCADOPAGO_WEBHOOK_SECRET = config('MERCADOPAGO_WEBHOOK_SECRET', default='')

# =============================================================================
# ANALYTICS
# =============================================================================

GA_TRACKING_ID = config('GA_TRACKING_ID', default='')

# =============================================================================
# PRODUCTION SECURITY CHECKS
# =============================================================================

if not DEBUG:
    # Check for missing critical credentials in production
    _missing_credentials = []

    if not EMAIL_HOST_PASSWORD:
        _missing_credentials.append('EMAIL_HOST_PASSWORD')

    if not MERCADOPAGO_ACCESS_TOKEN:
        _missing_credentials.append('MERCADOPAGO_ACCESS_TOKEN')

    if not MERCADOPAGO_WEBHOOK_SECRET:
        _missing_credentials.append('MERCADOPAGO_WEBHOOK_SECRET')

    if _missing_credentials:
        warnings.warn(
            f"Production mode with missing credentials: {', '.join(_missing_credentials)}. "
            "Some features may not work correctly.",
            RuntimeWarning
        )

    # Verify email backend is not console in production
    if 'console' in EMAIL_BACKEND.lower():
        warnings.warn(
            "EMAIL_BACKEND is set to console in production. "
            "Emails will not be sent. Configure SMTP settings.",
            RuntimeWarning
        )

# =============================================================================
# LOGGING
# =============================================================================

LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'verbose': {
            'format': '{levelname} {asctime} {module} {process:d} {thread:d} {message}',
            'style': '{',
        },
        'simple': {
            'format': '{levelname} {message}',
            'style': '{',
        },
    },
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
            'formatter': 'simple',
        },
        'file': {
            'class': 'logging.FileHandler',
            'filename': BASE_DIR / 'logs' / 'django.log',
            'formatter': 'verbose',
        },
    },
    'root': {
        'handlers': ['console'],
        'level': 'INFO',
    },
    'loggers': {
        'django': {
            'handlers': ['console'],
            'level': 'INFO',
            'propagate': False,
        },
    },
}

# Create logs directory if it doesn't exist
(BASE_DIR / 'logs').mkdir(exist_ok=True)
